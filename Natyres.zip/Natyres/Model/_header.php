<link rel="stylesheet" href="_header.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/4efbae73ca.js" crossorigin="anonymous"></script>

<header>
    <nav class="menu">
        <ul class="menu-list">
            <li class="menu-item"><a href="#">Accueil</a></li>
            <li class="menu-item"><a href="#">Taxons</a></li>
            <li class="menu-item"><a href="#">Actualités</a></li>
            <li class="menu-item"><a href="#">Contact</a></li>
            <li class="menu-item"><a href="#" class="fa fa-search"></a></li>
        </ul>
    </nav>
</header>