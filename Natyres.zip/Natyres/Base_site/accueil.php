<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil - Natyres</title>
</head>
<body>
    <header>
        <nav class="navbar">
            <ul>
                <li><img src="" alt=""></li>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
                <li></li>
            </ul>
        </nav>
    </header>

    <div class="background_top">
        <img src="" alt="">
        <div class="bg_text_top">
            <h4></h4>
            <p></p>
        </div>
    </div>

    <div class="about_us">
        <div class="left_content">
            <ul>

            </ul>
        </div>
        <div class="right_content">
            <h3></h3>
            <p></p>
        </div>
    </div>

    <footer>
        <img class="footer_logo" src="" alt="">
        <aside class="newsletter">
            <h3></h3>
        </aside>
        <nav class="footer_navlinks">
            <ul>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
                <li><a href=""></a></li>
            </ul>
        </nav>
        <p></p>
    </footer>

</body>
</html>